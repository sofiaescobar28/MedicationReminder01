package sv.edu.catolica.medicationreminder;

public class EMedicamento {
    int MED_COD;
    String MED_NOMBRE;
    String MED_TIPO;
}
