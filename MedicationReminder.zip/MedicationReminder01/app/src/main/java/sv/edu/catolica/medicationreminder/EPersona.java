package sv.edu.catolica.medicationreminder;

public class EPersona {
    int PER_COD;
    String PER_NOMBRE;
}
