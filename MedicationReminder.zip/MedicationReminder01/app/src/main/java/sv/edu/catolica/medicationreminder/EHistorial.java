package sv.edu.catolica.medicationreminder;

public class EHistorial {
    int H_COD;
    String RECORDATORIO;
    String H_FECHA;
    String H_ESTADO;
    String H_COMENTARIO;
    String DOSIFICACION;
    String DOSIS;
    String MEDxRE;
    String MEDICAMENTO;

}
