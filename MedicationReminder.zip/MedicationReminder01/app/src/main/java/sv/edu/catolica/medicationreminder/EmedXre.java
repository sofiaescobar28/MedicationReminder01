package sv.edu.catolica.medicationreminder;

public class EmedXre extends  EMedicamento {
    String MEDXRED_DOSIFICACION;
    String RE_DOSIS;
}
